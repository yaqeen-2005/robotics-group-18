# Factory busy training data

Generated from the `training_factory_busy` 40 x 30 aisle template.
`tasks.jsonl` contains start/goal grid coordinates and an unweighted shortest-path length for each task. Risk labels are the four values in `attributes.txt`.
